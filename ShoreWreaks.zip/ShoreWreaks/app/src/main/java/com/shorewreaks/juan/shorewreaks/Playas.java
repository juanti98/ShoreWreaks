package com.shorewreaks.juan.shorewreaks;

import android.os.Bundle;
import android.app.Activity;

public class Playas extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playas);
    }

}
